package com.PageFactory;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;

public class utility 
{   
	static WebDriver wd;
	public static WebDriver startBrowser (String browsename,String URL)
	
	{
		if (browsename.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			ChromeOptions options= new ChromeOptions();
			options.setAcceptInsecureCerts(true);
			 wd = new ChromeDriver(options);
			new WebDriverWait(wd, Duration.ofSeconds(20));
			
		}
		else if (browsename.equalsIgnoreCase("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions options= new FirefoxOptions();
			options.setAcceptInsecureCerts(true);
			wd=new FirefoxDriver(options);
			 wd.manage().window().maximize();
			
		}
		else if (browsename.equalsIgnoreCase("IE"))
		{
			WebDriverManager.edgedriver().setup();
			wd=new InternetExplorerDriver();
		}
		wd.manage().window().maximize();
		new WebDriverWait(wd, Duration.ofSeconds(20));
		wd.get(URL);
		
		return wd;
		
	}
	
	public void Dropdown(By drp_Ele, String visible) {
		// WebElement myEleDp = wd.findElement(By.id(cat));
		Select dropdown = new Select((WebElement) drp_Ele);// For select Hardware Type
		dropdown.selectByVisibleText(visible);

	}
	
	public void Dropdown1(WebElement cat, String visible)
	{
		// WebElement myEleDp = wd.findElement(By.id(cat));
		Select dropdown = new Select(cat);// For select Hardware Type
		dropdown.selectByVisibleText(visible);

	}
	
	public boolean isInvisible(WebElement Element, WebDriver wd, long tm)
	{
		boolean isDisplayed = false;

		try {

			WebDriverWait wt = new WebDriverWait(wd, Duration.ofSeconds(tm));
			wt.until(ExpectedConditions.invisibilityOf(Element));
			isDisplayed = true;
		} catch (Exception e)

		{

			e.printStackTrace();

		}

		return isDisplayed;

	}
	
	
	public boolean isDisaplyed(By Locator, WebDriver wd, long tm) 
	{
		boolean isDisplayed = false;

		try {

			WebDriverWait wt = new WebDriverWait(wd, Duration.ofSeconds(tm));
			wt.until(ExpectedConditions.visibilityOfElementLocated(Locator));
			isDisplayed = true;
		} catch (Exception e)

		{

			e.printStackTrace();

		}

		return isDisplayed;

	}
	
	public void login(WebDriver wd, String url, String User, String Pass)
	{

		// if(url=="https://fusionpro.verixo.net/Login.aspx")2
		//WebElement cer=wd.findElement(By.id("details-button"));
		//WebDriverWait wt = new WebDriverWait(wd, Duration.ofSeconds(10));
		//WebElement abc=wt.until(ExpectedConditions.visibilityOf(cer));
		
		//||(abc.isDisplayed())
		
		//if (url.contains("192.168")) 
		//{
			wd.get(url);
			
			//wd.findElement(By.id("details-button")).click();
			//wd.findElement(By.id("proceed-link")).click();
		//} else {
		//	wd.get(url);
		//}

		wd.manage().window().maximize();
		wd.findElement(By.id("UserName")).sendKeys(User);
		wd.findElement(By.name("Password")).sendKeys(Pass);
		wd.findElement(By.id("btnLogin")).click();
		System.out.println("Login Sucessfull");

	}
	
	//Print Message
	public void print(WebDriver wd, String id, String cat)
	{
		WebElement print_msg = wd.findElement(By.id(id));
		String text = print_msg.getText();
		System.out.println(cat + " " + text);
	
	}
	//URL Checking
	public void checkUrl(WebDriver wd) {

		String url = "";
		HttpURLConnection huc = null;
		int respCode = 200;

		List<WebElement> links = wd.findElements((By.xpath("//ul[@class='nav navbar-nav pull-right']//a")));
		Iterator<WebElement> it = links.iterator();

		while (it.hasNext()) {

			url = it.next().getAttribute("href");

			if (url != null && url.endsWith(".aspx")) 
			{
				System.out.println(url);

				try {
					huc = (HttpURLConnection) (new URL(url).openConnection());

					huc.setRequestMethod("HEAD");

					huc.connect();

					respCode = huc.getResponseCode();

					if (respCode >= 400) {
						System.out.println(url + " is a broken link");
					} else {
						System.out.println(url + " :-( Is a valid link)");
					}

				} catch (MalformedURLException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			continue;
		}
	
	}
	
	
}
