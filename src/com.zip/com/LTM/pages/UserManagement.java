package com.LTM.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class UserManagement

{

	public WebDriver wd;

	// To Acess User Management

	@FindBy(xpath = "//li[@id='divConfigurationSetup']")
	WebElement tabconfig;

	@FindBy(xpath = "//div[@id='btnExpandMenu']")
	WebElement btnExpandMenu;

	@FindBy(xpath = "//label[@title='User management']")
	WebElement clickusermgm;

	// Create New user role

	@FindBy(xpath = "//label[@id='ContentPlaceHolder0_lblMenuUserRole']")
	WebElement tabuserrole;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnnewUserRole']")
	WebElement btnaddnewrole;

	@FindBy(xpath = "//input[@id='txt_UserRole']")
	WebElement txtrolename;

	@FindBy(xpath = "//input[@id='txt_UserDescription']")
	WebElement txtroledesc;

	// if full acess just click on save button

	@FindBy(xpath = "(//input[@id='idModulesWindowsRolechkAllFull_Access'])[1]")
	WebElement winfullacess;

	@FindBy(xpath = "(//input[@id='idModulesWindowsRolechkAllRead'])[1]")
	WebElement winreadacess;

	@FindBy(xpath = "(//input[@id='idModulesWindowsRolechkAlNo_Access'])[1]")
	WebElement winnoacess;

	@FindBy(xpath = "(//input[@id='idModuleLinuxRolechkAllFull_Access'])[1]")
	WebElement linuxfullacess;

	@FindBy(xpath = "(//input[@id='idModuleLinuxRolechkAllRead'])[1]")
	WebElement linuxreadacess;

	@FindBy(xpath = "(//input[@id='idModuleLinuxRolechkAllNoAccess'])[1]")
	WebElement linuxnoacess;

	@FindBy(xpath = "(//input[@id='idModulesApplicationSettingsRolechkAllFull_Access'])[1]")
	WebElement appsetfullacess;

	@FindBy(xpath = "(//input[@id='idModulesApplicationSettingsRolechkAllRead'])[1]")
	WebElement appsetreadacess;

	@FindBy(xpath = "(//input[@id='idModulesApplicationSettingsRolechkAllNo_Access'])[1]")
	WebElement appsetnoacess;

	@FindBy(xpath = "(//input[@id='idModulesReportsRolechkAllFull_Access'])[1]")
	WebElement reportfullacess;

	@FindBy(xpath = "(//input[@id='idModulesReportsRolechkAllRead'])[1]")
	WebElement reportreadacess;

	@FindBy(xpath = "(//input[@id='idModulesReportsRolechkAlNoAccess'])[1]")
	WebElement reportnoacess;

	@FindBy(xpath = "(//input[@id='idModuleRemoteControlSettingsRolechkAllFull_Access'])[1]")
	WebElement contexmenufullacess;

	@FindBy(xpath = "(//input[@id='idModuleRemoteControlSettingsRolechkAllRead'])[1]")
	WebElement contexmenureadacess;

	@FindBy(xpath = "(//input[@id='idModuleRemoteControlSettingsRolechkAlNoAccess'])[1]")
	WebElement contexmenunoacess;

	@FindBy(xpath = "(//input[@id='iddivRemoteSettingsFullAccess'])[1]")
	WebElement contexmenuremotefullacess;

	@FindBy(xpath = "(//input[@id='iddivRemoteSettingsReadAccess'])[1]")
	WebElement contexmenuremotereadacess;

	@FindBy(xpath = "(//input[@id='iddivRemoteSettingsNoAccess'])[1]")
	WebElement contexmenuremotenoacess;

	@FindBy(xpath = "(//input[@id='iddivGroupSettingsFull'])[1]")
	WebElement contexmenugrpfullacess;

	@FindBy(xpath = "(//input[@id='iddivGroupSettingsRead'])[1]")
	WebElement contexmenugrpreadacess;

	@FindBy(xpath = "(//input[@id='iddivGroupSettingsNA'])[1]")
	WebElement contexmenugrpnoacess;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnUserSaveRole']")
	WebElement btnsaveuserrole;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnUserCancelRole']")
	WebElement btncloseuserrole;

	// Create new user_Group

	@FindBy(xpath = "//label[@id='ContentPlaceHolder1_lblMenuUserGroup']")
	WebElement tabusergrp;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnAddNewUserGroup']")

	WebElement btnnewgroup;

	@FindBy(xpath = "//input[@id='txt_UserGroupName']")
	WebElement txtusergrp;

	@FindBy(xpath = "//select[@id='ddlSelectUserRole']")
	WebElement ddselectuserrole;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnSaveGroupDetails']")
	WebElement btnsaveusergrp;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCancelGroupDetails']")
	WebElement btncloseusergrp;

	// Create New User

	@FindBy(xpath = "//label[@id='ContentPlaceHolder1_lblMenuUser']")
	WebElement tabuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnNewUser']")
	WebElement btnnewuser;

	@FindBy(xpath = "//input[@id='txtUserName']")
	WebElement txtusername;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCheckAvailability']")
	WebElement brncheckuseravaible;

	@FindBy(xpath = "//label[@id='lbluserAuthentication']")
	WebElement lbluseravaibility;

	@FindBy(xpath = "//input[@id='txtNewPassword']")
	WebElement txtpassword;

	@FindBy(xpath = "//input[@id='txtConfirmPassword']")
	WebElement txtconfirmpassword;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnNext_userAuthentication']")
	WebElement btnuserauthnext;

	@FindBy(xpath = "//input[@id='txtUserDetailsFirstName']")
	WebElement txtfirstname;

	@FindBy(xpath = "//input[@id='txtUserDetailsLastName']")
	WebElement txtlastname;

	@FindBy(xpath = "//input[@id='txtUserDetailsEmailID']")
	WebElement txtEmailid;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnBack_personalDetails']")
	WebElement btnbackuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnNext_personalDetails']")
	WebElement btnnextpersonaldetailsuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCancel_personalDetails']")
	WebElement btncloseuser;

	@FindBy(xpath = "//select[@id='ddlSelectUserGroup']")
	WebElement ddselectusergrp;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnBack_associationDetails']")
	WebElement btnbacknewuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnSave_associationDetails']")
	WebElement btnsavenewuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCancel_associationDetails']")
	WebElement btnclosenewuser;

	@FindBy(xpath = "//label[@id='lblSaveGroupDetailsMessage']")
	WebElement lblsavenewuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnRefrsh']")
	WebElement btnrefresh;

	// Domain user

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnDomainUser']")
	WebElement tabDomainUser;

	@FindBy(xpath = "//input[@id='txtDomainName']")
	WebElement txtDomainName;

	@FindBy(xpath = "//input[@id='txtDomainUser']")
	WebElement txtDomainUserName;

	@FindBy(xpath = "//input[@id='txtDomainPassword']")
	WebElement txtDomainPassword;

	@FindBy(xpath = "//select[@id='tbConUser_tbNewUser_DropDownListType']")
	WebElement ddDomainType;

	@FindBy(xpath = "//input[@id='tbConUser_tbNewUser_TxtSearch']")
	WebElement txtSearch;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnOKDomain']")
	WebElement btnDomainOk;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCancelDomain']")
	WebElement btnDomainClose;

	@FindBy(xpath = "//label[@id='lblDomainMessage']")
	WebElement msgDomainOk;

	@FindBy(xpath = "(//input[@type='search'])[3]")
	WebElement txtserchdomain;

	@FindBy(xpath = "(//input[@class='dt-checkboxes'])[1]")
	WebElement rdbtnselectDomainusergrp;

	@FindBy(xpath = "//select[@id='selDomainUserUserGroup']")
	WebElement ddselectusergrpDomain;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnSaveDomainUser']")
	WebElement btnsaveDomainuser;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCancelDomainUserDetails']")
	WebElement btncloseDomainuser;

	// Mailer Engine
	@FindBy(xpath = "(//label[@title='Mailer Engine Configuration'])[2]")
	WebElement tabmailerEngine;

	@FindBy(xpath = "//label[@id='ContentPlaceHolder1_lblmenuSMTPServerConfiguration']")
	WebElement tabSmtpServerConfig;

	@FindBy(xpath = "//input[@id='txtSmtpServerAddress']")
	WebElement txtSmtpServer;

	@FindBy(xpath = "//input[@id='txtAccName']")
	WebElement txtSmtpAccountName;

	@FindBy(xpath = "//input[@id='txtPassword']")
	WebElement txtSmtpPassword;

	@FindBy(xpath = "//input[@id='chkPort']")
	WebElement rdSmtpenableSSL;

	@FindBy(xpath = "//input[@id='txtSenderAddress']")
	WebElement txtSmtpDisplayName;

	@FindBy(xpath = "//input[@id='txtPort']")
	WebElement txtSmtpPortNo;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnSaveSMPT']")
	WebElement btnSmtpSave;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnTestSMPT']")
	WebElement btnSmtpTestConnection;

	@FindBy(xpath = "//label[@id='ContentPlaceHolder1_lblSaveSMPT']")
	WebElement lblSmtpcontest;

	public UserManagement(WebDriver wd) 
	{
		this.wd = wd;
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		PageFactory.initElements(wd, this);
	}

	public void userrole(String Role_Name) 
	{
		tabconfig.click();
		btnExpandMenu.click();
		clickusermgm.click();
		tabuserrole.click();
		btnaddnewrole.click();
		txtrolename.sendKeys(Role_Name);
		txtroledesc.sendKeys(Role_Name);
		if (Role_Name.contains("Full_Read")) {
			winfullacess.click();
			linuxreadacess.click();
			appsetfullacess.click();
			reportreadacess.click();
			contexmenufullacess.click();
			contexmenuremotereadacess.click();

		}
		if (Role_Name.contains("Read_no")) {
			winreadacess.click();
			linuxnoacess.click();
			appsetnoacess.click();
			reportnoacess.click();
			contexmenureadacess.click();
			contexmenuremotenoacess.click();

		}

	}

	public void usergrp(String Usergrp) 
	{
		tabusergrp.click();
		btnnewgroup.click();
		txtusergrp.sendKeys(Usergrp);

		if (Usergrp.contains("Full_Read")) {
			Select dropdown = new Select(ddselectuserrole);
			dropdown.selectByVisibleText(Usergrp);

		}
		if (Usergrp.contains("Read_no")) {
			Select dropdown = new Select(ddselectuserrole);
			dropdown.selectByVisibleText(Usergrp);

		}
		btnsavenewuser.click();
		btnclosenewuser.click();
		String return_Msg = lblsavenewuser.getText();
		Assert.assertEquals(return_Msg, "Saved Successfully");

	}

	public void createmixuser(String Username, String Password, String FName, String LName, String Email, String Usergrp) {
		tabuser.click();
		btnnewuser.clear();
		txtusername.sendKeys(Username);
		brncheckuseravaible.click();
		String user = lbluseravaibility.getText();
		if (user.contains("already exists")) {
			System.out.println("This User name all ready Exist");
			btncloseuser.click();
		}
		txtpassword.sendKeys(Password);
		txtconfirmpassword.sendKeys(Password);
		btnuserauthnext.click();
		txtfirstname.sendKeys(FName);
		txtlastname.sendKeys(LName);
		txtEmailid.sendKeys(Email);
		btnnextpersonaldetailsuser.click();

		Select dropdown = new Select(ddselectusergrp);
		dropdown.selectByVisibleText(Usergrp);
		btnsavenewuser.click();
		btnclosenewuser.click();

	}

	public void domainuser(String DName, String DUser, String DPassword)
	{
		tabDomainUser.click();
		txtDomainName.sendKeys(DName);
		txtDomainUserName.sendKeys(DUser);
		txtDomainUserName.sendKeys(DPassword);
		Select dropdown = new Select(ddDomainType);
		dropdown.selectByVisibleText("Domain User Groups");
		btnDomainOk.click();
		txtserchdomain.sendKeys("Administrator");
		rdbtnselectDomainusergrp.click();
		txtserchdomain.sendKeys("DomainUser");
		rdbtnselectDomainusergrp.click();
		Select dduser = new Select(ddselectusergrpDomain);
		dduser.selectByVisibleText("ADMIN");
		btnsaveDomainuser.click();
		btncloseDomainuser.click();
		btnDomainClose.click();
	}

	// Mailer Engine Confugration
	public void mailerEngine()
	{
		tabconfig.click();
		btnExpandMenu.click();
		tabmailerEngine.click();
		tabSmtpServerConfig.click();
		txtSmtpServer.sendKeys("mail.vxlsoftware.com");
		txtSmtpDisplayName.sendKeys("Support_Admin");
		txtSmtpAccountName.sendKeys("support@vxlsoftware.com");
		txtSmtpPortNo.sendKeys("25");
		txtSmtpPassword.sendKeys("VXl#124");
		if (rdSmtpenableSSL.isSelected()) {
			btnSmtpTestConnection.click();
		}

		else {
			rdSmtpenableSSL.click();
			btnSmtpTestConnection.click();

		}
		String Return_MSG = lblSmtpcontest.getText();
		Assert.assertEquals(Return_MSG, "Time Zone Settings applied successfully.");
		System.out.println(Return_MSG);
		btnSmtpSave.click();

	}
	
	//Default User
	
	public void defaultnoacessuser() 
	{
	 clickusermgm.click();
	 tabuser.click();
	 tabusergrp.click();
	 btnnewuser.click();
	 txtusername.sendKeys("no");
	 txtpassword.sendKeys("admin@123");
	 txtconfirmpassword.sendKeys("admin@123");
	 btnuserauthnext.click();
	 btnuserauthnext.click();
	 txtfirstname.sendKeys("no");
	 txtlastname.sendKeys("no");
	 txtEmailid.sendKeys("no@no.com");
	 btnnextpersonaldetailsuser.click();
	 Select ddusergrp = new Select(ddselectusergrp);
	 ddusergrp.selectByVisibleText("NO ACCESS");
	 btnclosenewuser.click();
	}
	
	public void defaultnreadcessuser() 
	{
	 clickusermgm.click();
	 tabuser.click();
	 tabusergrp.click();
	 btnnewuser.click();
	 txtusername.sendKeys("read");
	 txtpassword.sendKeys("admin@123");
	 txtconfirmpassword.sendKeys("admin@123");
	 btnuserauthnext.click();
	 txtfirstname.sendKeys("read");
	 txtlastname.sendKeys("read");
	 txtEmailid.sendKeys("read@read.com");
	 btnnextpersonaldetailsuser.click();
	 Select ddusergrp = new Select(ddselectusergrp);
	 ddusergrp.selectByVisibleText("READ");
	 btnclosenewuser.click();
	}

	public void defaultnadmincessuser() 
	{
	 clickusermgm.click();
	 tabuser.click();
	 tabusergrp.click();
	 btnnewuser.click();
	 txtusername.sendKeys("Rajendra");
	 txtpassword.sendKeys("admin@123");
	 txtconfirmpassword.sendKeys("admin@123");
	 btnuserauthnext.click();
	 txtfirstname.sendKeys("Rajendra");
	 txtlastname.sendKeys("Mane");
	 txtEmailid.sendKeys("rajendra.mane@vxlsoftware.com");
	 btnnextpersonaldetailsuser.click();
	 Select ddusergrp = new Select(ddselectusergrp);
	 ddusergrp.selectByVisibleText("ADMIN");
	 btnclosenewuser.click();
	}

	
}
