package com.LTM.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class login 
{
	WebDriver wd;
	By username = By.id("UserName");
	By password = By.id("Password");
	By login = By.id("btnLogin");
	By Terminal =By.xpath("//span[@id='ViewHeader']");
	//By details_Button=By.id("details-button");
	//By proceed_Link=By.id("proceed-link");

	public login(WebDriver wd)
	  {
		this.wd = wd;
	  }
	
	public void login_details(String User,String Pass)
	{
	wd.findElement(username).sendKeys(User);
		wd.findElement(password).sendKeys(Pass);
		wd.findElement(login).click();
		System.out.println("0.Login Sucessfull");
		
		
	}
/*
	public void user(String User) 
	  {
		wd.findElement(username).sendKeys(User);
	  }

	public void pass(String Pass)
		{
		wd.findElement(password).sendKeys(Pass);
		}

	public void loginbt() 
		{
		wd.findElement(login).click();
		}
    */
}
