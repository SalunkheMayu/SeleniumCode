package com.LTM.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.PageFactory.utility;

public class teradici
{
	public WebDriver wd;
   
	//Object Of utility
	utility sel= new utility();	
	//Mouse Action
    
	@FindBy (xpath="//a[@id='ibtntHome']")
     WebElement btnhome;
	
	@FindBy (id="btnExpandMenu")
	WebElement ExpandMenu;
	
	@FindBy(linkText="Teradici")
	WebElement Teradicci;
	
	@FindBy(linkText="Trust Center Configuration")
	WebElement Trust;
	
	@FindBy(linkText="Teradici Configuration")
	WebElement Tera_Con;
	
	@FindBy(xpath="(//i[@class='fa fa-refresh'])[3]")
	WebElement Click_Trust;
	
	@FindBy(id="btnSyncTrustCenterOk")
	WebElement Sync_Ok;
	
	@FindBy(xpath="//*[contains(text(), 'TERADICI')]//preceding-sibling::span[@class='rtPlus']")
	WebElement Grp;
	
	@FindBy(xpath="//*[contains(text(), '192.168.2.37')]")
	WebElement Node;
	
	@FindBy(linkText="Upgrade Management")
	WebElement Upgrade;
	@FindBy(linkText="Software Upgrade Management")
	WebElement Soft_mng;
	
	@FindBy(id="btnteradiciSoftwareupgrade")
	WebElement FirmUd;
	
	@FindBy (xpath = "//label[@id='lblCSTeradiciSoftwareupgrade']")
	WebElement lblfirmwareupgrade;
	
	@FindBy(xpath="(//label[@title='Desired'][normalize-space()='Desired'])[2]")
	WebElement Desired;
	
	@FindBy(xpath="(//label[@title='Trusted Broker'][normalize-space()='Trusted Broker'])[2]")
	WebElement Trsut_Broker;
	
	@FindBy(id="btnteradiciadd")
	WebElement Trust_Add;
	
	@FindBy(id="TD_txtaddress")
	WebElement Trust_address; //teraagent2.vdi.com
	
	@FindBy(id="TD_txtConntype")
	WebElement drp_Ele;
	
	@FindBy(xpath="//input[@id='TD_btntrustedbroker']")
	WebElement Trust_Apply;
	
	@FindBy(id="TD_lblMsg_trustedbroker")
	WebElement Trusted_Broker;
	
	@FindBy(id="btnteradiciclose")
	WebElement Trusted_Close;
	
	@FindBy(id="TD_lblMsg_trustedbroker")
	WebElement Trusted_Broker_MSG;
	
	@FindBy(id="btnsynctrustcenter")
	WebElement All_Sync;
	
	@FindBy (xpath="//div[@class='col-md-12 loading']")
	WebElement loader;
	
	@FindBy (xpath="//input[@id='btnSyncTrustCenterOk']")
	WebElement btnok;
	
	
	@FindBy (xpath="a[onclick=\"$('#divSyncTrustCenterAuto').removeClass('hidden');\"]")
	WebElement trustdevice;
	
	@FindBy(id="txtTeradiciNTPAddress")
	WebElement T_Address;
	
	@FindBy(id="txtTeradiciNTPPort")
	WebElement T_Port;
	
	@FindBy(id="txtTeradiciNTPIntervalSec")
	WebElement T_Query_Int;
	
	@FindBy(id="btnTeradiciNTPApply")
	WebElement NTP_apply;
	
	@FindBy(xpath="//label[@id='lblTeradiciNTPApplyMsg']")
	WebElement NTP_Lable;
	
	@FindBy(xpath = "//label[@id='lblTeradiciTimeZoneTabs']")
	WebElement tabTime_zone;
	
	@FindBy(id="ddlTeradiciTimezone")
	WebElement Drp_Time_Zone;
	
	@FindBy(id="txtTeradiciTimezoneTimeDisFormate")
	WebElement Time_Dis_Format;
	
	@FindBy(id="btnTeradiciTimezoneApply")
	WebElement Time_Zone_Apply;
	
	@FindBy(xpath="(//label[@title='Date & Time'][normalize-space()='Date & Time'])[4]")
	WebElement Date_Time;
	@FindBy(linkText="Time Zone")
	WebElement NTP;
	
	@FindBy(id="lblTeradiciTimezoneApplyMsg")
	WebElement Time_Zone_lbl;
	
	@FindBy(xpath="(//label[@title='Log Level'][normalize-space()='Log Level'])[2]")
	WebElement Log_Level;
	
	@FindBy(id="txtTeradiciLogLevel")
	WebElement Drp_Log;
	
	@FindBy(id="btnTeradiciLogLevelApply")
	WebElement Log_Apply;
	
	@FindBy(id="TD_lblMsg_loglevel")
	WebElement Log_label;
	
	@FindBy(linkText="Command")
	WebElement Command;
	
	@FindBy(linkText="Restart")
	WebElement Restart;
	
	@FindBy(id="btnTeadiciRebootAPPLY")
	WebElement Restart_Apply;
	
	@FindBy(id="lblTeadiciRebootApplyMsg")
	WebElement Restsrt_Label;
	
	@FindBy(linkText="Factory Reset")
	WebElement Factory_Reset;
	
	@FindBy(id="btnTeradiciFactoryResetApply")
	WebElement Factory_Apply;
	
	@FindBy(id="lblTeradiciFactoryResetApplyMsg")
	WebElement Factory_Label;
	
	@FindBy(xpath="(//label[@title='Shutdown'])[2]")
	WebElement Shutdown;
	
	@FindBy(xpath ="//input[@id=btnTeradiciPowerOffApply]")
	WebElement btnShutdownApply;
	
	@FindBy (xpath = "//label[@id='lblTeradiciPowerOffApplyMsg']")
	WebElement lblshutdownmsg;
	
	public teradici(WebDriver wd)
	{
		this.wd = wd;
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		PageFactory.initElements(wd, this);
	}
	

	
	
	public void trust_cen_config()
	{
		ExpandMenu.click();
		Teradicci.click();
		Trust.click();
		Tera_Con.click();
		All_Sync.click(); //For All Sync Center
		WebDriverWait wait = new WebDriverWait(wd, Duration.ofSeconds(50));
		wait.until(ExpectedConditions.invisibilityOf(loader));
		btnok.click();
		wait.until(ExpectedConditions.visibilityOf(btnhome));
		System.out.println("1:Trust Center Sync Sucessfully ");
		
	}
	
	
	public void firemware()
	{
		WebDriverWait wait = new WebDriverWait(wd, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOf(Grp));
		Grp.click();
		Node.click();
		ExpandMenu.click();
		Upgrade.click();
		Soft_mng.click();
		FirmUd.click();
		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@id='theprogress']//div[@class='col-md-12 loading']")));
		String Return_MSG=lblfirmwareupgrade.getText();
		Assert.assertEquals(Return_MSG, "Software Details Downlaoded successfully.");
		System.out.println("2.Firmware Upgrade Sucessfully");
		
	}
	
	public void trust_broker(String Trust_add,String visible)
	{
		Desired.click();
		Trsut_Broker.click();
		Trust_Add.click();
		Trust_address.sendKeys(Trust_add);
		
		Select dropdown = new Select(drp_Ele);
		dropdown.selectByVisibleText(visible);
		Trust_Apply.click();
        String Return_MSG=Trusted_Broker_MSG.getText();
        Assert.assertEquals(Return_MSG, "Trusted Broker Settings applied successfully.");
		System.out.println("3:Trusted Broker Test Pass");
		Trusted_Close.click();
			
		
	}
	
	public void datetime_NTP(String Address,String Port,String Query_Int)
	{
		//(Desired).click();
		Date_Time.click();
		//(NTP).click();
		T_Address.sendKeys(Address);
		T_Port.sendKeys(Port);
		T_Query_Int.sendKeys(Query_Int);
		NTP_apply.click();
		String Return_MSG=NTP_Lable.getText();
		Assert.assertEquals(Return_MSG,"NTP Settings applied successfully.");
		System.out.println("4:NTP TimeZone Test Pass");
		
		
		
	}
	
	public void Time_Zone(String Time_Z,String Time_Format)
	{
		tabTime_zone.click();
		Select dropdown = new Select(Drp_Time_Zone);
		dropdown.selectByVisibleText(Time_Z);
		Time_Dis_Format.sendKeys(Time_Format);
		Time_Zone_Apply.click();
		String Return_MSG=(Time_Zone_lbl).getText();
		Assert.assertEquals(Return_MSG, "Time Zone Settings applied successfully.");
		System.out.println("4:Time Zone Test Pass");
		
	}
	public void log_level(String Log)

	{
		Log_Level.click();
		
		Select dropdown = new Select(Drp_Log);
		dropdown.selectByVisibleText(Log);
		Log_Apply.click();
		String Return_MSG=Log_label.getText();
		Assert.assertEquals(Return_MSG, "Log level Settings applied successfully.");
		System.out.println("5:Log Level Test Pass");
		
	}
	
	public void command_Restart()
	{
		Command.click();
		Restart.click();
		Restart_Apply.click();
		String Return_MSG=Restsrt_Label.getText();
		Assert.assertEquals(Return_MSG, "Restart Settings applied successfully.");
		System.out.println("6:Restart Test Pass");
		
		
	}
	
	public void command_FactoryReset()
	{
		Factory_Reset.click();
		Factory_Apply.click();
		String Return_MSG=Factory_Label.getText();
		Assert.assertEquals(Return_MSG, "Factory Reset Settings applied successfully.");
		System.out.println("7:Factory Reset Test Pass");
		
	}
	
	
	public void command_Shutdown()
	{
      Shutdown.click();
      btnShutdownApply.click();
      String Return_MSG=lblshutdownmsg.getText();
      Assert.assertEquals(Return_MSG, "Shutdown Settings applied successfully.");
      
		
	}
	
}

