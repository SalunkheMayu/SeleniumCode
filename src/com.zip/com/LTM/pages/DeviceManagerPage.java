package com.LTM.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class DeviceManagerPage 

{
	public WebDriver wd;
	@FindBy(xpath="//*[contains(text(), 'DM_GRP')]//preceding-sibling::span[@class='rtPlus']")
	WebElement clickGrp;
	
	@FindBy(xpath="(//*[contains(text(), '192.168.1.188')])[1]")
	WebElement clickNode;
	
	@FindBy(xpath = "//div[@id='btnExpandMenu']")
	WebElement btnExpandMenu;
	
	@FindBy(xpath="(//label[@title='System Settings'])[3]")
	WebElement systemset;
	
	@FindBy (xpath="(//label[@title='Network Settings'])[3]")
	WebElement networkset;
	
	@FindBy (xpath="(//label[@title='Computer Name'])[3]")
	WebElement computername;
	
	@FindBy (xpath="//label[@id='XP_ComputerName_lblMenuCmptrName']")
	WebElement tabcomname;
	
	@FindBy (xpath="//input[@id='XP_ComputerName_chkAutomatically']")
	WebElement rdbtnautogenerate;
	
	@FindBy(xpath = "//input[@id='XP_ComputerName_txtDmianUname']")
	WebElement txtComUname;
	
	@FindBy(xpath = "//input[@id='XP_ComputerName_txtDmianPassword']")
	WebElement txtComPassoword;
	
	@FindBy(xpath = "//input[@id='XP_ComputerName_btnComputerNameApplyJQ']")
	WebElement ButtonApplycomputername;
	
	@FindBy(xpath="//label[@id='XP_ComputerName_lblMessage']")
	WebElement labcomputername;
	
	@FindBy (xpath="//label[@id='XP_ComputerName_lblMenuDomain']")
	WebElement tabdomain;
	
	@FindBy (xpath="//input[@id='XP_ComputerName_rbtnWorkGroup']")
	WebElement rdbtnworkgrp;
	
	@FindBy (xpath="//input[@id='XP_ComputerName_txtWorkgroup']")
	WebElement txtname;
	
	@FindBy (xpath="//input[@id='XP_ComputerName_txtUserName']")
	WebElement txtdmusername;
	
	@FindBy (xpath="//input[@id='XP_ComputerName_txtPassword']")
	WebElement txtdmpassword;
	
	@FindBy (xpath="//input[@id='XP_ComputerName_btnComputerNameApplyJQ']")
	WebElement btnapplydomain;

	
	
	public DeviceManagerPage(WebDriver wd)
	{
		this.wd = wd;
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		PageFactory.initElements(wd, this);
	}

	
	
  public void setComputerName(String User1,String Pass1)
  {
	  clickGrp.click();
	  clickNode.click();
	  btnExpandMenu.click();
	  systemset.click();
	  networkset.click();
	  computername.click();
	  tabcomname.click();
	  txtComUname.sendKeys(User1);
	  txtComPassoword.sendKeys(Pass1);
	  ButtonApplycomputername.click();
	  String Return_Msg=labcomputername.getText();
	  Assert.assertEquals(Return_Msg, "Computer Name Settings applied successfully");
	  
  }
  public void setDomainName(String name,String User2,String Pass2)
  {
	  computername.click();
	  tabdomain.click();
	  rdbtnworkgrp.click();
	  txtname.clear();
	  txtname.sendKeys(name);
	  txtdmusername.sendKeys(User2);
	  txtdmpassword.sendKeys(Pass2);
	  btnapplydomain.click();
	  String Return_Msg=labcomputername.getText();
	  Assert.assertEquals(Return_Msg, "Computer Name Settings applied successfully");
  }
	
}
