package com.LTM.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
//import org.testng.Assert;

import com.PageFactory.utility;

public class ConfigurationSetupPage {


	public WebDriver driver;
	private final String xlsPath= "C:\\Users\\Administrator\\Desktop\\Agent Setup\\LTMData.xlsx";


	utility selUtility=new utility();

	@FindBy(xpath = "//i[@class='icon-home dsico-Simple']")
	public WebElement homeIcon;


	@FindBy(xpath = "//div[@id='btnExpandMenu']")
	WebElement btnExpandMenu;

	@FindBy(xpath = "//a[@id='btSPAdmin']")
	WebElement btSPAdmin;


	@FindBy(xpath = "//a[@id='A12']")
	WebElement connTab;



	@FindBy(xpath = "(//li[@id='lblMenu_Repository'])[2]")
	WebElement lblMenu_Repository;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_newConnection']")
	WebElement btnNewConn;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_txtConnection']")
	WebElement txtConnName;
	
	@FindBy(xpath = "//select[@id='ContentPlaceHolder1_ddlProtocolType']")
	WebElement ddlProtocolType;
	
	@FindBy(xpath = "//select[@id='ContentPlaceHolder1_ddlRepository']")
	WebElement ddlRepository;
	
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_txtIPServer']")
	WebElement txtipserver;
	
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_txtAgentIP']")
	WebElement txtAgentIp;

	@FindBy(xpath = "//select[@id='ContentPlaceHolder1_ddlFTPType']")
	WebElement ddlFtpType;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_txtPortConnection']")
	WebElement txtPortConnection;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_FolderPath']")
	WebElement txtFolderPath;
	
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_UserName']")
	WebElement txtUserName;
	
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_passwordtxt']")
	WebElement txtpwd;
	
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_txtCertificateName']")
	WebElement txtCertificateName;
	
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_txtDomain']")
	WebElement txtDomain;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_Defaultchk']")
	WebElement chkDefaultRepo;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_chkgloballink']")
	WebElement chkgloballink;


	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnVldtCnnctn']")
	WebElement btnValidate;


	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_SaveConnection']")
	WebElement btnSave;


	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnCloseRp']")
	WebElement btnClose;

	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_btnrefesh']")
	WebElement btnRefresh;
	
	@FindBy (xpath="//input[@aria-controls='LoadRepositorytable']")
	WebElement Searchbar;
	
	@FindBy (xpath="(//a[@class='fa fa-refresh'])[6]")
	WebElement clicksyncrepo;
	
	@FindBy (xpath="//div[@id='divSyncConnnectionFiles']//label")
	WebElement lblreturnmsg;
	
	@FindBy (xpath="//span[@id='ContentPlaceHolder1_lblErrorMsgForAddConnection']")
	WebElement labvalidatecon;
	
	@FindBy (xpath="//div[@class='col-md-12 loading']")
	WebElement Loader;
	
	

	public ConfigurationSetupPage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Power option
	@FindBy (xpath="//select[@id='XPPowerOption_ddlPowerplan']")
	WebElement ddpowerplan;
	
	@FindBy (xpath="//select[@id='XPPowerOption_ddlDisplay']")
	WebElement dddisplay;
	
	@FindBy (xpath="//select[@id='XPPowerOption_ddlSleep']")
	WebElement ddsleep;
	
	@FindBy (xpath="//input[@id='XPPowerOption_btnAdvanceSettingsNew']")
	WebElement btnadvanceset;
	
	@FindBy (xpath="//select[@id='ddlTurnoffharddiskafter']")
	WebElement ddturnofhddafter;
	
	@FindBy (xpath="//select[@id='ddlSleepafter']")
	WebElement ddsleepafter;
	
	@FindBy (xpath="//select[@id='ddlTurnoffdisplayafter']")
	WebElement ddturndisplayafter;
	
	@FindBy (xpath="//select[@id='ddlSystemstandby']")
	WebElement ddsysstandby;
	
	@FindBy (xpath="//select[@id='ddlPowerbuttonaction']")
	WebElement ddpowerbtnaction;
	
	@FindBy (xpath="//select[@id='ddlSleepbuttonaction']")
	WebElement ddsleepbtnaction;
	
	@FindBy (xpath="//input[@id='XPPowerOption_btnSave']")
	WebElement btnsave;
	
	@FindBy (xpath="//input[@id='XPPowerOption_btnClose']")
	WebElement btnclose;
	
	@FindBy (xpath="//input[@id='XPPowerOption_btnPowerOptionSave']")
	WebElement btnapplypower;
	
	//printer
	@FindBy (xpath="//input[@id='XPPrinter_btnNewPrinter']")
	WebElement btnadd;
	
	@FindBy (xpath="//select[@id='XPPrinter_ddlPrinterType']")
    WebElement ddporttype;
	
	@FindBy (xpath="//input[@id='XPPrinter_txtLocalPrinterName']")
	WebElement txtprintername;
	
	@FindBy (xpath="//select[@id='XPPrinter_ddlManufacturer']")
	WebElement ddmanufacture;
	
	@FindBy (xpath="//select[@id='XPPrinter_ddlPrinterDriverLists']")
	WebElement ddprinterdevicelist;
	
	@FindBy (xpath="//select[@id='XPPrinter_ddlPortlist']")
	WebElement ddport;
	
	@FindBy (xpath="//input[@id='XPPrinter_rbtnShared']")
	WebElement rdshared;
	
	@FindBy (xpath="//input[@id='XPPrinter_rbtnNotShared']")
	WebElement rdnotshared;
	
	@FindBy (xpath="//input[@id='XPPrinter_btnXPPrinter']")
	WebElement btnprintersetapply;
	
	
	@FindBy (xpath="//input[@id='XPPrinter_btnCloseXPPrinter']")
	WebElement btncloseprinter;
	
	@FindBy (xpath="//input[@id='XPPrinter_txtIPAddress']")
	WebElement textip;
	
	@FindBy (xpath="//input[@id='XPPrinter_txtNwUserName']")
	WebElement txtusername;
	
	@FindBy (xpath="//input[@id='XPPrinter_txtNwPassword']")
	WebElement txtpassword;
	

	public void  openRepo()
	{
		//open repo form 

		(btSPAdmin).click();;
		(btnExpandMenu).click();;
		lblMenu_Repository.click();;
		(connTab).click();;
		(btnNewConn).click();;

		try {

			File xlsFile=new File(xlsPath);
			FileInputStream inputStream=new FileInputStream(xlsFile);
			@SuppressWarnings("resource")
			XSSFWorkbook wb=new XSSFWorkbook(inputStream);
			XSSFSheet sheet=wb.getSheet("CreateRepo");

			int totalNoOfRows,totalNoOfCells;

			totalNoOfRows=sheet.getLastRowNum()-sheet.getFirstRowNum();
			totalNoOfCells=sheet.getRow(0).getPhysicalNumberOfCells();

			System.out.println("Rows"+totalNoOfRows+" and " +"Column"+ totalNoOfCells);


			for (int i=0;i<=totalNoOfRows;i++)
			{		

				//open new form 
				(btnNewConn).click();;
				//enter details for repo.
				String protocolType,repotypedata,ftpSsl;
				txtConnName.sendKeys(sheet.getRow(i).getCell(0).getStringCellValue());
				//selUtility.setText(sheet.getRow(i).getCell(0).getStringCellValue(),txtConnName);
				Select protoType=new Select(ddlProtocolType);
				protocolType=sheet.getRow(i).getCell(1).getStringCellValue();
				protoType.selectByValue(protocolType);

				Select repoType=new Select(ddlRepository);
				repotypedata=sheet.getRow(i).getCell(2).getStringCellValue();
				repoType.selectByValue(repotypedata);
				txtipserver.sendKeys(sheet.getRow(i).getCell(3).getStringCellValue());
				txtAgentIp.sendKeys(sheet.getRow(i).getCell(4).getStringCellValue());
				//selUtility.setText(sheet.getRow(i).getCell(3).getStringCellValue(),txtipserver);
				//selUtility.setText(sheet.getRow(i).getCell(4).getStringCellValue(),txtAgentIp);

				if(ddlFtpType.isEnabled()==true)
				{				

					Select ftpsslddl=new Select(ddlFtpType);
					ftpSsl=sheet.getRow(i).getCell(5).getStringCellValue();
					ftpsslddl.selectByValue(ftpSsl);
				}

				//selUtility.setText(String.valueOf(sheet.getRow(i).getCell(6).getNumericCellValue()),txtPortConnection);
				txtFolderPath.sendKeys(sheet.getRow(i).getCell(6).getStringCellValue());
				txtUserName.sendKeys(sheet.getRow(i).getCell(7).getStringCellValue());
				txtpwd.sendKeys(sheet.getRow(i).getCell(8).getStringCellValue());
				//selUtility.setText(sheet.getRow(i).getCell(6).getStringCellValue(),txtFolderPath);
				//selUtility.setText(sheet.getRow(i).getCell(7).getStringCellValue(),txtUserName);
				//System.out.println("Password : "+sheet.getRow(i).getCell(8).getStringCellValue());
				//selUtility.setText(sheet.getRow(i).getCell(8).getStringCellValue(),txtpwd);
						
				txtDomain.sendKeys(sheet.getRow(i).getCell(9).getStringCellValue());
				//selUtility.setText(sheet.getRow(i).getCell(9).getStringCellValue(),txtDomain);
				btnSave.click();
				btnValidate.click();
				String msg=labvalidatecon.getText();
				/*Assert.assertEquals(msg, "Connection failed.");
				{
				 	
				}*/
				if(msg.contains("Connection failed.")||msg.contains("Invalid"))
				{
					 System.out.println(sheet.getRow(i).getCell(0).getStringCellValue()+ ":-"+msg);	
					// (btnClose).click();
				}
				else
				{
					System.out.println(sheet.getRow(i).getCell(0).getStringCellValue()+ ":-"+msg);
					//(btnClose).click();
				}
				(btnClose).click();
			}	
		}

		catch (Exception e) {
			System.out.println(e.getMessage());

		}	

		
		
		
	}
	public void  syncRepo() throws IOException
	{
		//Open Repo
		//(btSPAdmin).click();
		//(btnExpandMenu).click();
		//lblMenu_Repository.click();
		(connTab).click();
		//(btnNewConn).click();
		
		File xlsFile=new File(xlsPath);
		FileInputStream inputStream=new FileInputStream(xlsFile);
		@SuppressWarnings("resource")
		XSSFWorkbook wb=new XSSFWorkbook(inputStream);
		XSSFSheet sheet=wb.getSheet("CreateRepo");
		
		int totalNoOfRows,totalNoOfCells;

		totalNoOfRows=sheet.getLastRowNum()-sheet.getFirstRowNum();
		totalNoOfCells=sheet.getRow(0).getPhysicalNumberOfCells();

		System.out.println("Rows"+totalNoOfRows+" and " +"Column"+ totalNoOfCells);


		for (int i=0;i<=totalNoOfRows;i++)
		{
			
			Searchbar.sendKeys(sheet.getRow(i).getCell(0).getStringCellValue());
			clicksyncrepo.click();
			if( selUtility.isInvisible(Loader, driver, 30)==true);
			
			String Msg=lblreturnmsg.getText();
			
			
			if(Msg.contains("successfully"))
			{
				System.out.println(Msg);
				//Searchbar.clear();
				
			}
			else
			{
				System.out.println(Msg);
				//Searchbar.clear();
			}
			Searchbar.clear();
		}
		

		
	}
}
