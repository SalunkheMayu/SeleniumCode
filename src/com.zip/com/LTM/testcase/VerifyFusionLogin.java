package com.LTM.testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

import com.LTM.pages.ConfigurationSetupPage;
import com.LTM.pages.DeviceManagerPage;
import com.LTM.pages.login;
import com.PageFactory.utility;

public class VerifyFusionLogin {

	//public WebDriver driver;
	//FusionLoginPage login=new FusionLoginPage(driver);
	
	utility selUtility=new utility();
	WebDriver wd= utility.startBrowser("chrome", "https://192.168.5.109");
	DeviceManagerPage dm=new DeviceManagerPage(wd);
	
	
	
	//private final String xlsPath= "C:\\Users\\Administrator\\Desktop\\Agent Setup\\LTMData.xlsx";
	
	/* Create an instance of Soft Assert */
	Assertion softAssert = new SoftAssert();
	login abc = new login(wd);
	//verifylogin login=new verifylogin();
	
	ConfigurationSetupPage con= new ConfigurationSetupPage(wd);
	
	@Test (priority=1)
	public void login()
	{
		//login.loginpage();
		abc.login_details("admin","admin");
		if (selUtility.isDisaplyed(By.id("ibtntHome"), wd, 6000) == true);
		
		
	}
	
	
	@Test(priority=2)
	public void deviceMangeerComputer()
	{
	  dm.setComputerName("asit","asit#123");
	  //dm.setDomainName("WORKGROUP","administrator","000000");
	  
	}
	
	@Test(priority=3)
	public void deviceMangeerDomian()
	{
	  //dm.setComputerName("asit","asit#123");
	  dm.setDomainName("WORKGROUP","administrator","000000");
	  
	}

	@Test (priority=4)
	public void quit()
	{
		wd.quit();
	}
}
	
	
/*
	/*{
		test=extent.createTest("Invalid User login").assignAuthor("Mateen").assignCategory("Functional Test Case").assignDevice("Windows");
		FusionLoginPage login=new FusionLoginPage(driver);
		ConfigurationSetupPage configPage=new ConfigurationSetupPage(driver);
		login.LoginButton("admin","admin");
	//	Assert.assertEquals(login.errorMesssageDisplay(), false);
		
		
		configPage.openRepo();
		
		
	//	driver.close();
		
	}*/

	//@Test (priority=1)

	/*public void verifyValidUserLogin()

	{	
		//DeviceManagerPage dmPage=new DeviceManagerPage(driver);

		//test=extent.createTest("Valid User login").assignAuthor("Vinayak").assignCategory("Functional Test Case").assignDevice("Windows");
		//FusionLoginPage login=new FusionLoginPage(driver);
		
		
		
		try {

			File xlsFile=new File(xlsPath);
			FileInputStream inputStream=new FileInputStream(xlsFile);
			@SuppressWarnings("resource")
			XSSFWorkbook wb=new XSSFWorkbook(inputStream);
			XSSFSheet sheet=wb.getSheet("logindetails");

			@SuppressWarnings("unused")
			int totalNoOfRows,totalNoOfCells;

			totalNoOfRows=sheet.getLastRowNum()-sheet.getFirstRowNum();
			totalNoOfCells=sheet.getRow(0).getPhysicalNumberOfCells();;
		

			for (int i=0;i<=totalNoOfRows;i++)
			{			
					
					String userName=sheet.getRow(i).getCell(0).getStringCellValue();
					String pwd=sheet.getRow(i).getCell(1).getStringCellValue();
					
					System.out.println(userName+ " and " + pwd);
					abc.login_details(userName,pwd);
					if (selUtility.isDisaplyed(By.id("ibtntHome"), wd, 6000) == true);
					
					
			}
			
		}
		
	 catch (Exception e) 
	{
		System.out.println(e.getMessage());
	}

		
		
		
}	
	//@Test (priority=2)	
	public void openrepo()
	{
	  con.openRepo();
	}
	//@Test (priority=3)
	public void syncRepo() throws IOException
	{
		con.syncRepo();
	}
	
 @Test (priority=4)
	public void quit()
	{
		wd.quit();
	}
 }
 
	/*login.LoginButton(userName,pwd);
					
					if (login.errorMesssageDisplay()==true)
					{
						
						
						System.out.println(userName+" and " + pwd +"Incorrect.");
						
						
					}else
						
					{
					
						dmPage.verifySuccessLoggin();
						System.out.printl
						n(userName+" and " + pwd +"correct.");
					}
					
					//create a new cell in the row at index 6
					//XSSFCell cell = sheet.getRow(i).createCell(6);
					
					//Boolean result=login.LoginButton(userName, pwd).verifySuccessLoggin();
					
					//check if confirmation message is displayed
//					if (result==true){
//						// if the message is displayed , write PASS in the excel sheet
//						cell.setCellValue("PASS");
//
//					} else {
//						//if the message is not displayed , write FAIL in the excel sheet
//						cell.setCellValue("FAIL");
//					}
//
//					// Write the data back in the Excel file
//					FileOutputStream outputStream = new FileOutputStream(xlsPath);
//					wb.write(outputStream);


			}*/

		
		//}	
		
	//	selUtil.readWriteXls();
//		System.out.println("Assert DM logo visible Passed!");
//		
//		checking form load 
//		FormLoadCheckPage frmLoad=new FormLoadCheckPage(driver);
//		frmLoad.checkUrlStatus();
//		
//		
//		//logout process
		/*HeaderPage headerPage=new HeaderPage(driver);
		headerPage.logoutSuccess();
		System.out.println("Assert  logout module test case Passed!");*/	
	
	
	
	
	/* @Test(enabled=false,description="veriftLogoutMoudle")

	public void veriftLogoutMoudle()
	{
		test=extent.createTest("Verify Logout Module").assignAuthor("Vinayak").assignCategory("Functional Test Case").assignDevice("Windows");
		
		HeaderPage headerPage=new HeaderPage(driver);
		headerPage.logoutSuccess();
		System.out.println("Assert  logout module test case Passed!");	
	}*/
	
	
//}





