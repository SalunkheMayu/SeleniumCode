package com.LTM.testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.LTM.pages.login;
import com.LTM.pages.teradici;
import com.PageFactory.utility;

public class synctrust
{
	
	WebDriver wd= utility.startBrowser("chrome", "https://192.168.5.104");
	
	utility sel= new utility();
	teradici tr= new teradici(wd);
	
	
	@Test (priority=1)
	public void login()
	{
		login abc = new login(wd);
		abc.login_details("admin","admin");
		if (sel.isDisaplyed(By.id("ibtntHome"), wd, 6000) == true);
		
	}

	@Test (priority=2)
	public void trust_cen_config()
	{
		
		tr.trust_cen_config();
		if (sel.isDisaplyed(By.id("ibtntHome"), wd, 7000) == true);
	}

	@Test (priority=3)
	public void firemware()
	{
		tr.firemware();
		
	}
	
	@Test (priority=4)
	public void trust_broker()
	{
		tr.trust_broker("teraagent.vdi.com","Direct");
		
	}
	
	@Test (priority=5)
	public void datetime_NTP()
	{
		tr.datetime_NTP("times.google.com", "143", "86350");
	}
	
	@Test (priority=6)
	public void Time_Zone()
	{
		tr.Time_Zone("Africa/Abidjan", "%b %d %Y %H:%M:%S");
	}
	@Test (priority=7)
	public void log_level()
	{
		tr.log_level("error");
	}

	
	@Test (priority=8)
	public void command_Restart()
	{
		tr.command_Restart();
	}
	
	
	@Test (priority=9)
	public void command_FactoryReset()
	{
		tr.command_FactoryReset();
		
		
	}
	@Test (priority=10)
	public void shutdown()
	{
		tr.command_Shutdown();
	}
	@Test (priority=11)
	public void quit()
	{
	
		wd.quit();
	}
	
	
	
}


