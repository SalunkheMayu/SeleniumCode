package com.LTM.testcase;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.LTM.pages.login;
import com.PageFactory.utility;

public class verifylogin 
{
	@Test
	public void loginpage() 
	{

		//WebDriverManager.chromedriver().setup();
		//ChromeOptions options= new ChromeOptions();
		//options.setAcceptInsecureCerts(true);
		//WebDriver wd = new ChromeDriver(options);
		WebDriver wd= utility.startBrowser("chrome", "https://192.168.5.109");
		//wd.get("https://192.168.5.109");
		utility Selutil=new utility();
		login ab = new login(wd);
		ab.login_details("rajendra","admin@123");
		boolean display=(Selutil.isDisaplyed(By.xpath("//span[@id='ViewHeader']"), wd, 30));
		////label[@id='lblFailureText']
		Assert.assertEquals(display,true);
			   			 
			
		
	wd.close();

	}
}
